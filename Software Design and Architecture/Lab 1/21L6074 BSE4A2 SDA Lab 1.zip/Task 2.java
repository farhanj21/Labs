import java.util.Scanner;

class Multiplication
{
    public static void main(String[] args)
    {
        Scanner x = new Scanner(System.in);
        System.out.print("Enter an integer: ");
        int n = x.nextInt();
        System.out.print("Input number of terms: ");
        int num = x.nextInt();

        for (int i = 0; i <= num; i++) {
            System.out.println(n + " x " + i + " = " + n * i);
        }
    }
}